/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package View;

import Controller.*;
import Model.BigIntegerNumber;
import Model.BinaryNum;
import Model.DecimalNum;
import Model.HexNum;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;


/**
 * @author Dino Jazvin
 * This class is resposible setting
 * up and assembling the GUI components.
 * And getting user input.
 */


public class InputProcessor {

    /* Initializing textfields */
    private static JTextField textField;
    private static JTextField textField2;
    private static JTextField textField3;
    private static JTextField textField4;
    private static JTextField textField5;
    private static JTextField textField6;
    private static JTextField textField7;
    private static JTextField textField8;
    private static JTextField textField9;
    private static JTextField textField10;
    private static JTextField textField11;
    private static JTextField textField12;
    private static JTextField textField13;
    private static JTextField textField14;
    private static JTextField textField15;
    private static JTextField textField16;
    private static JTextField textField17;
    private static JTextField textField18;
    private static JTextField textField19;
    private static JTextField textField20;

    /* Initializing numerical variables */
    private static String binaryNum1;
    private static String binaryNum2;
    private static String decimalNum;
    private static String decimalNum2;
    private static String decimalNum3;
    private static String hexNum1;
    private static String hexNum2;
    private static String doubleNum1;
    private static String doubleNum2;
    private static String bigInteger1;
    private static String bigInteger2;

    /* Initializing unit variables and ProcessOutput instance */
    private static String operation = "+";
    private static String units = "b";
    private static String bytesUnits = "B";
    private static String bitUnits = "b";
    private static String PageViewsValue = "Per Day";
    private static String avgPageSizeUnits = "B";
    private static String monthlyUsageUnits = "B";
    private static String hostingBandwidthUnits = "b";
    static final ProcessOutput output = new ProcessOutput();


    /**
     * Setting up and assembling all GUI components,
     * Jframes, Jbuttons, Jlabels, Jtextfields, and comboBoxes
     */
    public static void getCalculatorType() {
        JFrame frame = new JFrame("CALCULATOR");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900,900);
        frame.setLayout(new BorderLayout());
        // Scanner keyboard = new Scanner(System.in);
        JPanel panel1 = new JPanel(new FlowLayout());
        panel1.setPreferredSize(new Dimension(900,900));
        panel1.setBackground(Color.pink);
        panel1.setLayout(new GridLayout(3,4));
        frame.add(panel1, BorderLayout.CENTER);

        JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel2.setBackground(Color.cyan);

        JPanel panel3 = new JPanel(new FlowLayout());
        panel3.setBackground(Color.pink);

        JPanel panel4 = new JPanel(new FlowLayout());
        panel4.setBackground(Color.cyan);

        JPanel panel5 = new JPanel(new FlowLayout());
        panel5.setBackground(Color.pink);

        JPanel panel6 = new JPanel(new FlowLayout());
        panel6.setBackground(Color.pink);

        JPanel panel7 = new JPanel(new FlowLayout());
        panel7.setBackground(Color.cyan);

        JPanel panel8 = new JPanel(new FlowLayout());
        panel8.setBackground(Color.pink);

        JPanel panel9 = new JPanel(new FlowLayout());
        panel9.setBackground(Color.cyan);

        JPanel panel10 = new JPanel(new FlowLayout());
        panel10.setBackground(Color.cyan);

        JPanel panel11 = new JPanel(new FlowLayout());
        panel11.setBackground(Color.pink);

        JPanel panel12 = new JPanel(new FlowLayout());
        panel12.setBackground(Color.cyan);

        JPanel panel13 = new JPanel(new FlowLayout());
        panel13.setBackground(Color.pink);

        /* Binary Labels */
        JLabel label1 = new JLabel("BINARY CALCULATOR                             ");
        label1.setFont(new Font("Impact", Font.PLAIN, 18));
        JLabel label2 = new JLabel("CONVERT BINARY TO DECIMAL   ");
        label2.setFont(new Font("Impact", Font.PLAIN, 18));
        JLabel label3 = new JLabel("CONVERT DECIMAL TO BINARY   ");
        label3.setFont(new Font("Impact", Font.PLAIN, 18));

        /* Bandwidth Labels */
        JLabel label4 = new JLabel("DATA UNIT CONVERTER  ");
        label4.setFont(new Font("Impact", Font.PLAIN, 18));

        JLabel label5 = new JLabel("DOWNLOAD/UPLOAD TIME ");
        label5.setFont(new Font("Impact", Font.PLAIN, 18));
        JLabel labelFileSize = new JLabel("File Size ");
        JLabel labelBandwidth = new JLabel("Bandwidth  ");

        JLabel label6 = new JLabel("WEBSITE BANDWIDTH");
        label6.setFont(new Font("Impact", Font.PLAIN, 18));
        JLabel labelPageViews = new JLabel("Page Views ");
        JLabel labelAveragePageSize = new JLabel("Average Page Size  ");
        JLabel labelRedundancyFactor = new JLabel("              Redundancy Factor  ");

        JLabel label7 = new JLabel("HOSTING BANDWIDTH  ");
        label7.setFont(new Font("Impact", Font.PLAIN, 18));
        JLabel labelMonthlyUsage = new JLabel("Monthly Usage ");
        JLabel labelIsEquivalentTO = new JLabel("          is equivalent to         ");
        JLabel labelHostingBandwidth = new JLabel("Bandwidth  ");

        /* HEXADECIMAL LABELS */
        JLabel label8 = new JLabel("HEXADECIMAL CALCULATOR   ");
        label8.setFont(new Font("Impact", Font.PLAIN, 18));

        JLabel label9 = new JLabel("CONVERT HEX TO DECIMAL:   ");
        label9.setFont(new Font("Impact", Font.PLAIN, 18));
        JLabel labelHexValue = new JLabel("Hexadecimal Value:   ");

        JLabel label10 = new JLabel("CONVERT DECIMAL TO HEX:   ");
        label10.setFont(new Font("Impact", Font.PLAIN, 18));
        JLabel labelDecimalValue = new JLabel("Decimal Value:   ");


        /* Decimal Label */
        JLabel label11 = new JLabel("DECIMAL CALCULATOR:   ");
        label11.setFont(new Font("Impact", Font.PLAIN, 18));

        /* BigInteger Label */
        JLabel label12 = new JLabel("BIGINTEGER CALCULATOR:   ");
        label12.setFont(new Font("Impact", Font.PLAIN, 18));

        /* Binary Textfields */
        textField = new JTextField();
        textField.setPreferredSize(new Dimension(60,20));

        textField2 = new JTextField();
        textField2.setPreferredSize(new Dimension(60,20));

        textField3 = new JTextField();
        textField3.setPreferredSize(new Dimension(60,20));

        textField4 = new JTextField();
        textField4.setPreferredSize(new Dimension(60,20));

        /* Bandwidth Textfields */
        textField5 = new JTextField();
        textField5.setPreferredSize(new Dimension(60,20));

        textField6 = new JTextField();
        textField6.setPreferredSize(new Dimension(60,20));

        textField7 = new JTextField();
        textField7.setPreferredSize(new Dimension(60,20));

        textField8 = new JTextField();
        textField8.setPreferredSize(new Dimension(60,20));

        textField9 = new JTextField();
        textField9.setPreferredSize(new Dimension(60,20));

        textField10 = new JTextField();
        textField10.setPreferredSize(new Dimension(60,20));

        textField11 = new JTextField();
        textField11.setPreferredSize(new Dimension(60,20));

        textField12 = new JTextField();
        textField12.setPreferredSize(new Dimension(60,20));

        /* Hexadecimal Textfields */
        textField13 = new JTextField();
        textField13.setPreferredSize(new Dimension(60,20));

        textField14 = new JTextField();
        textField14.setPreferredSize(new Dimension(60,20));

        textField15 = new JTextField();
        textField15.setPreferredSize(new Dimension(60,20));

        textField16 = new JTextField();
        textField16.setPreferredSize(new Dimension(60,20));

        textField17 = new JTextField();
        textField17.setPreferredSize(new Dimension(60,20));

        textField18 = new JTextField();
        textField18.setPreferredSize(new Dimension(60,20));

        textField19 = new JTextField();
        textField19.setPreferredSize(new Dimension(60,20));

        textField20 = new JTextField();
        textField20.setPreferredSize(new Dimension(60,20));


        /*Textfields Listeners */
        textField.addActionListener(e -> binaryNum1 = textField.getText());
        textField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                binaryNum1 = textField.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                binaryNum1 = textField.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                binaryNum1 = textField.getText();
            }
        });

        textField2.addActionListener(e -> binaryNum2 = textField2.getText());
        textField2.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                binaryNum2 = textField2.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                binaryNum2 = textField2.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                binaryNum2 = textField2.getText();
            }
        });

        textField3.addActionListener(e -> binaryNum1 = textField3.getText());
        textField3.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                binaryNum1 = textField3.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                binaryNum1 = textField3.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                binaryNum1 = textField3.getText();
            }
        });

        textField4.addActionListener(e -> decimalNum = textField4.getText());
        textField4.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                decimalNum = textField4.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                decimalNum = textField4.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                decimalNum = textField4.getText();
            }
        });

        textField5.addActionListener(e -> decimalNum = textField5.getText());
        textField5.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                decimalNum = textField5.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                decimalNum = textField5.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                decimalNum = textField5.getText();
            }
        });

        textField6.addActionListener(e -> decimalNum = textField6.getText());
        textField6.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                decimalNum = textField6.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                decimalNum = textField6.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                decimalNum = textField6.getText();
            }
        });


        textField7.addActionListener(e -> decimalNum2 = textField7.getText());
        textField7.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                decimalNum2 = textField7.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                decimalNum2 = textField7.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                decimalNum2 = textField7.getText();
            }
        });

        textField8.addActionListener(e -> decimalNum = textField8.getText());
        textField8.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                decimalNum = textField8.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                decimalNum = textField8.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                decimalNum = textField8.getText();
            }
        });

        textField9.addActionListener(e -> decimalNum2 = textField9.getText());
        textField9.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                decimalNum2 = textField9.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                decimalNum2 = textField9.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                decimalNum2 = textField9.getText();
            }
        });

        textField10.addActionListener(e -> decimalNum3 = textField10.getText());
        textField10.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                decimalNum3 = textField10.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                decimalNum3 = textField10.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                decimalNum3 = textField10.getText();
            }
        });

        textField11.addActionListener(e -> decimalNum = textField11.getText());
        textField11.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                decimalNum = textField11.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                decimalNum = textField11.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                decimalNum = textField11.getText();
            }
        });

        textField12.addActionListener(e -> decimalNum2 = textField10.getText());
        textField12.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                decimalNum2 = textField12.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                decimalNum2 = textField12.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                decimalNum2 = textField12.getText();
            }
        });

        textField13.addActionListener(e -> hexNum1 = textField13.getText());
        textField13.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                hexNum1 = textField13.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                hexNum1 = textField13.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                hexNum1 = textField13.getText();
            }
        });

        textField14.addActionListener(e -> hexNum2 = textField14.getText());
        textField14.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                hexNum2 = textField14.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                hexNum2 = textField14.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                hexNum2 = textField14.getText();
            }
        });

        textField15.addActionListener(e -> hexNum1 = textField15.getText());
        textField15.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                hexNum1 = textField15.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                hexNum1 = textField15.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                hexNum1 = textField15.getText();
            }
        });

        textField16.addActionListener(e -> decimalNum = textField16.getText());
        textField16.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                decimalNum = textField16.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                decimalNum = textField16.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                decimalNum = textField16.getText();
            }
        });

        textField17.addActionListener(e -> doubleNum1 = textField17.getText());
        textField17.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                doubleNum1 = textField17.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                doubleNum1 = textField17.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                doubleNum1 = textField17.getText();
            }
        });

        textField18.addActionListener(e -> doubleNum2 = textField18.getText());
        textField18.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                doubleNum2 = textField18.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                doubleNum2 = textField18.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                doubleNum2 = textField18.getText();
            }
        });

        textField19.addActionListener(e -> bigInteger1 = textField19.getText());
        textField19.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                bigInteger1 = textField19.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                bigInteger1 = textField19.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                bigInteger1 = textField19.getText();
            }
        });

        textField20.addActionListener(e -> bigInteger2 = textField20.getText());
        textField20.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                bigInteger2 = textField20.getText();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                bigInteger2 = textField20.getText();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                bigInteger2 = textField20.getText();
            }
        });

        /* ComboBoxes */
        String[] basicOperations = {"+","-","x","÷"};
        JComboBox<String> comboBox = new JComboBox<>(basicOperations);
        comboBox.addActionListener(e -> {
            if(e.getSource() == comboBox){
                operation = (String) comboBox.getSelectedItem();
            }
        });

        String[] bandwidthUnits = {"b","kb","mb","gb","tb","B","KB","MB","GB","TB"};
        JComboBox<String> comboBox2 = new JComboBox<>(bandwidthUnits);
        comboBox2.addActionListener(e -> {
            if(e.getSource() == comboBox2){
                units = (String) comboBox2.getSelectedItem();
            }
        });

        String[] theBytes = {"B","KB","MB","GB","TB"};
        JComboBox<String> comboBox3 = new JComboBox<>(theBytes);
        comboBox3.addActionListener(e -> {
            if(e.getSource() == comboBox3){
                bytesUnits = (String) comboBox3.getSelectedItem();
            }
        });

        String[] theBits = {"b","kb","mb","gb","tb"};
        JComboBox<String> comboBox4 = new JComboBox<>(theBits);
        comboBox4.addActionListener(e -> {
            if(e.getSource() == comboBox4){
                bitUnits = (String) comboBox4.getSelectedItem();
            }
        });


        String[] PageViewOptions = {"Per Second","Per Minute","Per Hour","Per Day","Per Week", "Per Month", "Per Year"};
        JComboBox<String> comboBox5 = new JComboBox<>(PageViewOptions);
        comboBox5.addActionListener(e ->  {
                if(e.getSource() == comboBox5){
                    PageViewsValue = (String) comboBox5.getSelectedItem();
                }
        });

        JComboBox<String> comboBox6 = new JComboBox<>(theBytes);
        comboBox6.addActionListener(e -> {
                if(e.getSource() == comboBox6){
                    avgPageSizeUnits = (String) comboBox6.getSelectedItem();
                }
        });


        JComboBox<String> comboBox7 = new JComboBox<>(theBytes);
        comboBox7.addActionListener(e ->  {
                if(e.getSource() == comboBox7){
                    monthlyUsageUnits = (String) comboBox7.getSelectedItem();
                }
        });

        JComboBox<String> comboBox8 = new JComboBox<>(theBits);
        comboBox8.addActionListener(e ->  {
                if(e.getSource() == comboBox8){
                    hostingBandwidthUnits = (String) comboBox8.getSelectedItem();
                }
        });

        JComboBox<String> comboBox9 = new JComboBox<>(basicOperations);
        comboBox9.addActionListener(e -> {
            if(e.getSource() == comboBox9){
                operation = (String) comboBox9.getSelectedItem();
            }
        });

        JComboBox<String> comboBox10 = new JComboBox<>(basicOperations);
        comboBox10.addActionListener(e -> {
            if(e.getSource() == comboBox10){
                operation = (String) comboBox10.getSelectedItem();
            }
        });

        JComboBox<String> comboBox11 = new JComboBox<>(basicOperations);
        comboBox11.addActionListener(e -> {
            if(e.getSource() == comboBox11){
                operation = (String) comboBox11.getSelectedItem();
            }
        });

        JButton binarySubmit = new JButton("Calculate \u25B6");
        binarySubmit.setBackground(Color.green);
        binarySubmit.addActionListener(e -> {
            if(e.getSource() == binarySubmit){
              processBinaryNumbers();
            }
        });

        JButton binary2DecimalButton = new JButton("Calculate \u25B6");
        binary2DecimalButton.setBackground(Color.green);
        binary2DecimalButton.addActionListener(e -> {
            if(e.getSource() == binary2DecimalButton){
                convertBinary2Decimal();
            }
        });

        JButton decimal2BinaryButton = new JButton("Calculate \u25B6");
        decimal2BinaryButton.setBackground(Color.green);
        decimal2BinaryButton.addActionListener(e -> {
            if(e.getSource() == decimal2BinaryButton){
                convertDecimal2Binary();
            }
        });

        JButton dataUnitConverterButton = new JButton("Calculate \u25B6");
        dataUnitConverterButton.setBackground(Color.green);
        dataUnitConverterButton.addActionListener(e -> {
            if(e.getSource() == dataUnitConverterButton){
                processDataUnitConverter();
            }
        });

        JButton downloadTimeButton = new JButton("Calculate \u25B6");
        downloadTimeButton.setBackground(Color.green);
        downloadTimeButton.addActionListener(e -> {
            if(e.getSource() == downloadTimeButton){
                processDownloadTime();
            }
        });

        JButton websiteBandwidthButton = new JButton("Calculate \u25B6");
        websiteBandwidthButton.setBackground(Color.green);
        websiteBandwidthButton.addActionListener(e -> {
            if(e.getSource() == websiteBandwidthButton){
                processWebsiteBandwidth();
            }
        });

        JButton hostingBandwidthButton = new JButton("Calculate \u25B6");
        hostingBandwidthButton.setBackground(Color.green);
        hostingBandwidthButton.addActionListener(e -> {
            if(e.getSource() == hostingBandwidthButton){
                processHostingBandwidth();
            }
        });

        JButton hexMathButton = new JButton("Calculate \u25B6");
        hexMathButton.setBackground(Color.green);
        hexMathButton.addActionListener(e -> {
            if(e.getSource() == hexMathButton){
                processHexAddSubtract();
            }
        });

        JButton hex2DecButton = new JButton("Calculate \u25B6");
        hex2DecButton.setBackground(Color.green);
        hex2DecButton.addActionListener(e -> {
            if(e.getSource() == hex2DecButton){
                Hex2Decimal();
            }
        });

        JButton dec2HexButton = new JButton("Calculate \u25B6");
        dec2HexButton.setBackground(Color.green);
        dec2HexButton.addActionListener(e -> {
            if(e.getSource() == dec2HexButton){
                Decimal2Hex();
            }
        });

        JButton DecimalButton = new JButton("Calculate \u25B6");
        DecimalButton.setBackground(Color.green);
        DecimalButton.addActionListener(e -> {
            if(e.getSource() == DecimalButton){
                DecimalMath();
            }
        });

        JButton BigIntegerButton = new JButton("Calculate \u25B6");
        BigIntegerButton.setBackground(Color.green);
        BigIntegerButton.addActionListener(e -> {
            if(e.getSource() == BigIntegerButton){
                bigIntegerMath();
            }
        });


        /* Document Listeners for Combo boxes */
        ((JTextField)comboBox.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        ((JTextField)comboBox2.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        ((JTextField)comboBox3.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        ((JTextField)comboBox4.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        ((JTextField)comboBox5.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        ((JTextField)comboBox6.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        ((JTextField)comboBox7.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        ((JTextField)comboBox8.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        ((JTextField)comboBox9.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        ((JTextField)comboBox10.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        ((JTextField)comboBox11.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });


        panel2.add(label1);
        panel2.add(textField);
        panel2.add(comboBox);
        panel2.add(textField2);
        panel2.add(binarySubmit);

        panel3.add(label2);
        panel3.add(textField3);
        panel3.add(binary2DecimalButton);

        panel4.add(label3);
        panel4.add(textField4);
        panel4.add(decimal2BinaryButton);

        panel5.add(label4);
        panel5.add(textField5);
        panel5.add(comboBox2);
        panel5.add(dataUnitConverterButton);

        panel6.add(label5);
        panel6.add(labelFileSize);
        panel6.add(textField6);
        panel6.add(comboBox3);
        panel6.add(labelBandwidth);
        panel6.add(textField7);
        panel6.add(comboBox4);
        panel6.add(downloadTimeButton);

        panel7.add(label6);
        panel7.add(labelPageViews);
        panel7.add(textField8);
        panel7.add(comboBox5);
        panel7.add(labelAveragePageSize);
        panel7.add(textField9);
        panel7.add(comboBox6);
        panel7.add(labelRedundancyFactor);
        panel7.add(new JLabel("                 "));
        panel7.add(textField10);
        panel7.add(new JLabel("                 "));
        panel7.add(websiteBandwidthButton);

        panel8.add(label7);
        panel8.add(labelMonthlyUsage);
        panel8.add(textField11);
        panel8.add(comboBox7);
        panel8.add(labelIsEquivalentTO);
        panel8.add(labelHostingBandwidth);
        panel8.add(textField12);
        panel8.add(comboBox8);
        panel8.add(hostingBandwidthButton);

        panel9.add(label8);
        panel9.add(textField13);
        panel9.add(comboBox9);
        panel9.add(textField14);
        panel9.add(hexMathButton);

        panel10.add(label9);
        panel10.add(labelHexValue);
        panel10.add(textField15);
        panel10.add(hex2DecButton);

        panel11.add(label10);
        panel11.add(labelDecimalValue);
        panel11.add(textField16);
        panel11.add(dec2HexButton);

        panel12.add(label11);
        panel12.add(textField17);
        panel12.add(comboBox10);
        panel12.add(textField18);
        panel12.add(DecimalButton);

        panel13.add(label12);
        panel13.add(textField19);
        panel13.add(comboBox11);
        panel13.add(textField20);
        panel13.add(BigIntegerButton);


        panel1.add(panel2);
        panel1.add(panel3);
        panel1.add(panel4);
        panel1.add(panel5);
        panel1.add(panel6);
        panel1.add(panel7);
        panel1.add(panel8);
        panel1.add(panel9);
        panel1.add(panel10);
        panel1.add(panel11);
        panel1.add(panel12);
        panel1.add(panel13);
        frame.setVisible(true);
    }


    /**
     * validating and processing binary values to be calculated
     */
    public static void processBinaryNumbers(){
        if(binaryValidation(binaryNum2) && binaryValidation(binaryNum1)){
            BinaryCalculator bc = new BinaryCalculator(new BinaryNum(binaryNum1), new BinaryNum(binaryNum2), operation);
        }
    }

    /**
     * adding and subtracting Hex values
     */
    public static void processHexAddSubtract(){
        if(hexValidation(hexNum1) && hexValidation(hexNum2)){
            HexadecimalCalculator hc = new HexadecimalCalculator(operation, new HexNum(hexNum1) , new HexNum(hexNum2));
        }
    }

    /**
     * Converting Hex to decimal
     */
    public static void Hex2Decimal(){
        if(hexValidation(hexNum1)){
            HexadecimalCalculator.HexadecimalConversion(1, new HexNum(hexNum1));
        }
    }

    /**
     * Converting decimal to Hex
     */
    public static void Decimal2Hex(){
        if(decimalValidation(decimalNum)){
            HexadecimalCalculator.HexadecimalConversion(0, new HexNum(decimalNum));
        }
    }


    /**
     * Sending Decimal math to output, (add, subtract, multiply, and divide)
     */
    public static void DecimalMath(){
        if(operation.equals("+")){
            if(decimalCalcValidation(doubleNum1) && decimalCalcValidation(doubleNum2)) {
                double result = DecimalCalculator.addDecimal(new DecimalNum(Double.parseDouble(doubleNum1)), new DecimalNum(Double.parseDouble(doubleNum2)));
                DecimalOutput.DecimalCalcOutput("+", new DecimalNum(Double.parseDouble(doubleNum1)), new DecimalNum(Double.parseDouble(doubleNum2)), result);
            }
        }
        if(operation.equals("-")){
            if(decimalCalcValidation(doubleNum1) && decimalCalcValidation(doubleNum2)) {
                double result = DecimalCalculator.subtractDecimal(new DecimalNum(Double.parseDouble(doubleNum1)), new DecimalNum(Double.parseDouble(doubleNum2)));
                DecimalOutput.DecimalCalcOutput("-", new DecimalNum(Double.parseDouble(doubleNum1)), new DecimalNum(Double.parseDouble(doubleNum2)), result);
            }
        }
        if(operation.equals("x")){
            if(decimalCalcValidation(doubleNum1) && decimalCalcValidation(doubleNum2)) {
                double result = DecimalCalculator.multiplyDecimal(new DecimalNum(Double.parseDouble(doubleNum1)), new DecimalNum(Double.parseDouble(doubleNum2)));
                DecimalOutput.DecimalCalcOutput("x", new DecimalNum(Double.parseDouble(doubleNum1)), new DecimalNum(Double.parseDouble(doubleNum2)), result);
            }
        }
        if(operation.equals("÷")){
            if(decimalCalcValidation(doubleNum1) && decimalCalcValidation(doubleNum2)) {
                double result = DecimalCalculator.divideDecimal(new DecimalNum(Double.parseDouble(doubleNum1)), new DecimalNum(Double.parseDouble(doubleNum2)));
                DecimalOutput.DecimalCalcOutput("÷", new DecimalNum(Double.parseDouble(doubleNum1)), new DecimalNum(Double.parseDouble(doubleNum2)), result);
            }
        }
    }

    /**
     * Sending bigInteger math to output, (add, subtract, multiply, and divide)
     */
    public static void bigIntegerMath(){
        //BigIntegerNumber bigIntegerVal1 = new BigIntegerNumber(new BigInteger(bigInteger1));
        switch (operation) {
            case "+":
                if (bigIntegerValidation(bigInteger1) && bigIntegerValidation(bigInteger2)) {
                    BigInteger result = BigIntegerCalculator.add(new BigIntegerNumber(new BigInteger(bigInteger1)), new BigIntegerNumber(new BigInteger(bigInteger2)));
                    BigIntegerOutput.bigIntOutput("+", new BigIntegerNumber(new BigInteger(bigInteger1)), new BigIntegerNumber(new BigInteger(bigInteger2)), result);
                }
                break;
            case "-":
                if (bigIntegerValidation(bigInteger1) && bigIntegerValidation(bigInteger2)) {
                    BigInteger result = BigIntegerCalculator.subtract(new BigIntegerNumber(new BigInteger(bigInteger1)), new BigIntegerNumber(new BigInteger(bigInteger2)));
                    BigIntegerOutput.bigIntOutput("-", new BigIntegerNumber(new BigInteger(bigInteger1)), new BigIntegerNumber(new BigInteger(bigInteger2)), result);
                }
                break;
            case "x":
                if (bigIntegerValidation(bigInteger1) && bigIntegerValidation(bigInteger2)) {
                    BigInteger result = BigIntegerCalculator.multiply(new BigIntegerNumber(new BigInteger(bigInteger1)), new BigIntegerNumber(new BigInteger(bigInteger2)));
                    BigIntegerOutput.bigIntOutput("x", new BigIntegerNumber(new BigInteger(bigInteger1)), new BigIntegerNumber(new BigInteger(bigInteger2)), result);
                }
                break;
            case "÷":
                if (bigIntegerValidation(bigInteger1) && bigIntegerValidation(bigInteger2)) {
                    BigInteger[] result = BigIntegerCalculator.divide(new BigIntegerNumber(new BigInteger(bigInteger1)), new BigIntegerNumber(new BigInteger(bigInteger2)));
                    BigIntegerOutput.bigIntDivisionOutput("÷", new BigIntegerNumber(new BigInteger(bigInteger1)), new BigIntegerNumber(new BigInteger(bigInteger2)), result);
                }
                break;
        }
    }

    /**
     * converting binary to decimal and sending to output class
     */
    public static void convertBinary2Decimal() {
        if (binaryValidation(binaryNum1)) {
            BinaryCalculator bc = new BinaryCalculator();
            int decimalVal = bc.convertBinary2Decimal(Integer.parseInt(binaryNum1));
            output.binary2DecimalOutput(decimalVal);
        }
    }

    /**
     * converting decimal to binary and sending to output class
     */
    public static void convertDecimal2Binary(){
        if (decimalValidation(decimalNum)) {
            BinaryCalculator bc = new BinaryCalculator();
            String binaryValue = bc.convertDecimal2Binary(Integer.parseInt(decimalNum));
            output.decimal2BinaryOutput(binaryValue);
        }
    }

    /**
     * sending data unit converter data to be calculated
     */
    public static void processDataUnitConverter(){
        if(decimalValidation(decimalNum)){
            BandwidthCalculator bandwidthCalculator = new BandwidthCalculator(Double.parseDouble(decimalNum), units, 1);
        }
    }

    /**
     * Processing download time data
     */
    public static void processDownloadTime() {
        if(decimalValidation(decimalNum) && decimalValidation(decimalNum2)) {
            int fileSizePosition = BandwidthCalculator.getByteUnitsPosition(bytesUnits);
            int bandwidthPosition = BandwidthCalculator.getDifferenceInBits(bitUnits);
            int difference = bandwidthPosition - fileSizePosition;
            BandwidthCalculator bandwidthCalculator = new BandwidthCalculator(difference, Double.parseDouble(decimalNum), Double.parseDouble(decimalNum2));
        }
    }

    /**
     * Processing website bandwidth data
     */
    public static void processWebsiteBandwidth() {
        if(decimalValidation(decimalNum) && decimalValidation(decimalNum2) && decimalValidation(decimalNum3)) {

            //Bandwidth starting values
            double bandwidthPerSecond = 8.0E-6;
            double bandwidthPerMonth = 0.0026298;

            //Scaling our values by the page views and average page size entered
            bandwidthPerSecond = bandwidthPerSecond * Double.parseDouble(decimalNum) * Double.parseDouble(decimalNum2);
            bandwidthPerMonth = bandwidthPerMonth * Double.parseDouble(decimalNum) * Double.parseDouble(decimalNum2);

            int pageViewsDifference = BandwidthCalculator.getPageViewDifference(PageViewsValue);
            int averagePageSizeDifference = BandwidthCalculator.getByteUnitsPosition(avgPageSizeUnits);

            bandwidthPerSecond = BandwidthCalculator.convertUsingUnits(pageViewsDifference, averagePageSizeDifference, bandwidthPerSecond);
            bandwidthPerMonth = BandwidthCalculator.convertUsingUnits(pageViewsDifference, averagePageSizeDifference, bandwidthPerMonth);

            ProcessOutput output = new ProcessOutput(bandwidthPerSecond, bandwidthPerMonth, Double.parseDouble(decimalNum3));
        }
    }

    /**
     * Processing hosting bandwidth values
     */
    public static void processHostingBandwidth(){
        double monthlyUsage;
        double bandwidth;
        double factor = 1;
        if(decimalValidation(decimalNum) && !decimalValidation(decimalNum2)){
            bandwidth = 3.0420564301468E-6;
            int monthlyUsagePosition = BandwidthCalculator.getByteUnitsPosition(monthlyUsageUnits);
            int bandwidthPosition = BandwidthCalculator.getDifferenceInBits(hostingBandwidthUnits);
            int difference = bandwidthPosition - monthlyUsagePosition;
            BandwidthCalculator bdw1 = new BandwidthCalculator(difference, factor, Double.parseDouble(decimalNum), monthlyUsageUnits, bandwidth, hostingBandwidthUnits);

        }
        else if(!decimalValidation(decimalNum) && decimalValidation(decimalNum2)){
            monthlyUsage = 328725;
            int monthlyUsagePosition = BandwidthCalculator.getByteUnitsPosition(monthlyUsageUnits);
            int bandwidthPosition = BandwidthCalculator.getDifferenceInBits(hostingBandwidthUnits);
            int difference = bandwidthPosition - monthlyUsagePosition;
            BandwidthCalculator bdw1 = new BandwidthCalculator(difference, factor, monthlyUsageUnits, monthlyUsage, Double.parseDouble(decimalNum2), hostingBandwidthUnits);
        }
    }

    /**
     * Validating Binary values
     * @param num binary value to be validated
     * @return true/false
     */
    public static boolean binaryValidation(String num){
        try {
            char[] chars = num.toCharArray();
            boolean isDone = false;
            while (!isDone) {
                for (int i = 0; i < chars.length; i++) {
                    if (chars[i] != '0' && chars[i] != '1') {
                        JOptionPane.showMessageDialog(null, "NOT A VALID BINARY NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
                        return false;

                    }
                    if(i == chars.length - 1){
                        return true;
                    }
                }
                isDone = true;
            }
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, "NOT A VALID BINARY NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if(num.equals("")) {
            JOptionPane.showMessageDialog(null, "NOT A VALID BINARY NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    /**
     //* Validate decimal values
     //* @return true/false
     */
    public static boolean decimalValidation(String val){

        try {
            int num = Integer.parseInt(val);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, "NOT A VALID DECIMAL NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if(val.equals("")) {
            JOptionPane.showMessageDialog(null, "NOT A VALID DECIMAL NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    /**
     * Validate decimalCalculator values
     * @return true/false
     */
    public static boolean decimalCalcValidation(String val){
        try {
            double num = Double.parseDouble(val);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, "NOT A VALID DECIMAL NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if(val.equals("")) {
            JOptionPane.showMessageDialog(null, "NOT A VALID DECIMAL NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }


    /**
     * Validate Hex input
     * @param theValue Hex value to check
     * @return true/false
     */
    public static boolean hexValidation(String theValue){
        String[] hexChars = {"-","0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"};
        ArrayList<String> hexCharsList = new ArrayList<>(Arrays.asList(hexChars));
            try {
                String[] arr = theValue.split("");

                    for (int i = 0; i < arr.length; i++) {
                        if (!hexCharsList.contains(arr[i])) {
                            JOptionPane.showMessageDialog(null, "NOT A VALID HEXADECIMAL NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
                            return false;
                        }
                        if (i == arr.length - 1) {
                            return true;
                        }
                    }
            }
            catch (Exception e){
                JOptionPane.showMessageDialog(null, "NOT A VALID HEXADECIMAL NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            if(theValue.equals("")) {
                JOptionPane.showMessageDialog(null, "NOT A VALID HEXADECIMAL NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        return true;
    }

    /**
     * Validating BigInteger input
     * @param theValue BigInteger value
     * @return true/false
     */
    public static boolean bigIntegerValidation(String theValue) {
        String[] BigInts = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
        ArrayList<String> BigIntChars = new ArrayList<>(Arrays.asList(BigInts));
            try {
                String[] arr = theValue.split("");
                    for (int i = 0; i < arr.length; i++) {
                        if (!BigIntChars.contains(arr[i])) {
                            JOptionPane.showMessageDialog(null, "NOT A VALID BIGINTEGER NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
                            return false;
                        }
                        if (i == arr.length - 1) {
                            return true;
                        }
                    }
            }
           catch (Exception e){
                JOptionPane.showMessageDialog(null, "NOT A VALID BIGINTEGER NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            if(theValue.equals("")) {
                JOptionPane.showMessageDialog(null, "NOT A VALID BIGINTEGER NUMBER", "WARNING", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        return true;
    }


}

