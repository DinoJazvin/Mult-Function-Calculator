/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */
package View;

import Controller.BandwidthCalculator;
import Model.HexNum;

import javax.swing.*;
import java.util.ArrayList;

/**
 * @author Dino Jazvin
 * This class is resposible for
 * properly formatting and displaying output
 */


public class ProcessOutput {

    /**
     * Displays output of binary addition
     */
    public void binaryAdditionOutput(String binarySum, String decimalSum){
        JOptionPane.showMessageDialog(null, "Binary Value: " + binarySum + "\nDecimal Value: " + decimalSum, "Binary Addition", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Displays output of binary subtraction
     */
    public void binarySubtractionOutput(String binaryVal, String decimalVal){
        JOptionPane.showMessageDialog(null, "Binary Value: " + binaryVal + "\nDecimal Value: " + decimalVal, "Binary Subtraction", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Displays output of binary multiplication
     */
    public void binaryMultiplicationOutput(String binaryVal, String decimalVal){
        JOptionPane.showMessageDialog(null, "Binary Value: " + binaryVal + "\nDecimal Value: " + decimalVal, "Binary Multiplication", JOptionPane.INFORMATION_MESSAGE);
    }


    /**
     * Displays output of binary division
     */
    public void binaryDivisionOutput(String binaryVal, String binaryRemainder, int decimalVal, int decimalRemainder){
        JOptionPane.showMessageDialog(null, "Binary Value: \n" + binaryVal + " Remainder : " + binaryRemainder  + "\nDecimal Value: \n" + decimalVal + " Remainder : " + decimalRemainder,"Binary Division", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Displays output of converting binary to decimal value
     * @param DecimalValue the decimal value being converted
     */
    public void binary2DecimalOutput(int DecimalValue){
        JOptionPane.showMessageDialog(null,"Decimal Value: " + DecimalValue,"Binary to Decimal", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Displays output of converting decimal to binary value
     * @param binaryVal the binary value being converted
     */
    public void decimal2BinaryOutput(String binaryVal){
        JOptionPane.showMessageDialog(null,"Binary Value: " + binaryVal,"Decimal to Binary", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * No-arg Constructor
     */
    public ProcessOutput() {
    }






    /**
     * Output of Bandwidth Data Converter
     * @param amount total amount
     * @param position index of the units
     * @param numberOfBits total number of bits
     * @param numberOfBytes total number of Bytes
     */
    public ProcessOutput(double amount, int position, double numberOfBits, double numberOfBytes) {
        BandwidthCalculator bdw1 = new BandwidthCalculator();
        String[] units = {"bits(b)", "kilobits(kb)", "megabits(mb)", "gigabits(gb)", "terabits(tb)", "Bytes(B)", "Kilobytes(KB)", "Megabytes(MB)", "Gigabytes(GB)", "Terabytes(TB)"};
        ArrayList<String> myList = new ArrayList<>();
        myList.add(amount + " " + units[position] + " is equivalent to any of the following: \n");
        for (int i = 0; i < 5; i++) {
            if(position != i) {
                myList.add((bdw1.DivideBy1000(numberOfBits, i)) + " " + units[i] + "\n");
            }
        }

        for (int i = 5; i < 10; i++) {
            if(position != i) {
                myList.add((bdw1.DivideBy1000(numberOfBytes, i-5)) + " " + units[i] + "\n");
            }
        }

        StringBuilder strb = new StringBuilder();
        for(String s : myList){
            strb.append(s).append("\n");
        }

        JOptionPane.showMessageDialog(null, strb,"Data Unit Converter", JOptionPane.INFORMATION_MESSAGE);


    }

    /**
     * Constructor for download/upload time
     * @param totalSeconds the total time in seconds
     * @param numberOfDays total number of days
     * @param numberOfHours total number of hours
     * @param numberOfMinutes total number of minutes
     */
    public ProcessOutput(double totalSeconds, int numberOfDays, int numberOfHours, int numberOfMinutes){
        StringBuilder strb = new StringBuilder();
        strb.append("Download or upload time needed is: \n");
        if (numberOfDays > 0)
            strb.append(numberOfDays).append(" Days \n");
        if (numberOfHours > 0)
            strb.append(numberOfHours).append(" Hours \n");
        if (numberOfMinutes > 0)
            strb.append(numberOfMinutes).append(" Minutes \n");
        if (totalSeconds > 0)
            strb.append(totalSeconds).append(" Seconds ");

        JOptionPane.showMessageDialog(null, strb,"Download/Upload Time Calculator", JOptionPane.INFORMATION_MESSAGE);

    }

    /**
     * Constructor for website bandwidth calc.
     * @param bandwidthPerSecond bandwidth per second
     * @param bandwidthPerMonth bandwidth per month
     * @param redundancyFactor redundancy factor
     */
    public ProcessOutput(double bandwidthPerSecond, double bandwidthPerMonth, double redundancyFactor){
        StringBuilder strb = new StringBuilder();
        strb.append("Actual bandwidth needed is: ").append(bandwidthPerSecond).append(" Mbits/s\n");
        strb.append("or ").append(bandwidthPerMonth).append(" GB per Month\n");
        if(redundancyFactor > 1){
            strb.append("With redundancy factor of ").append(redundancyFactor).append(", the bandwidth needed is ").append(bandwidthPerSecond*redundancyFactor).append(" Mbits/s or ").append(bandwidthPerMonth*redundancyFactor).append(" GB per month.\n");
        }
        JOptionPane.showMessageDialog(null, strb,"Website Bandwidth Calculator", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Output of hosting bandwidth (input monthly usage)
     * @param monthlyUsage the monthly usage
     * @param monthlyUsageUnits the units of monthly usage
     * @param totalBandwidth value of total bandwidth
     * @param bandwidthUnits units of bandwidth
     */
    public ProcessOutput(double monthlyUsage, String monthlyUsageUnits, double totalBandwidth, String bandwidthUnits) {
        JOptionPane.showMessageDialog(null, monthlyUsage + " (" + monthlyUsageUnits + ") per month is equivalent to \n" + totalBandwidth + " " + bandwidthUnits + "/s","Website Bandwidth Calculator", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Output of hosting bandwidth (input bandwidth)
     * @param bandwidthUnits bandwidth Units
     * @param bandwidth bandwidth amount
     * @param totalMonthlyUsage total monthly usage
     * @param monthlyUsageUnits monthly usage units
     */
    public ProcessOutput(String bandwidthUnits, double bandwidth, double totalMonthlyUsage, String monthlyUsageUnits) {
        JOptionPane.showMessageDialog(null, bandwidth + " " + bandwidthUnits + "it/s is equivalent to \n" + totalMonthlyUsage + " (" + monthlyUsageUnits + ") per month.","Website Bandwidth Calculator", JOptionPane.INFORMATION_MESSAGE);
 //       System.out.println(bandwidth + " " + bandwidthUnits + "it/s is equivalent to " + GREEN + totalMonthlyUsage + " (" + monthlyUsageUnits + ") per month.");
    }

    /**
     * Hex to decimal converter output
     * @param value decimal value
     */
    public static void Hex2DecimalConverter(String value){
            JOptionPane.showMessageDialog(null, "Decimal value: " + value,"Convert Hex to Decimal", JOptionPane.INFORMATION_MESSAGE);

    }


    /**
     * Hex to decimal converter output
     * @param value Hex value
     */
    public static void Decimal2HexConverter(String value){
            JOptionPane.showMessageDialog(null, "Hexadecimal value: " + value,"Convert Decimal to Hex", JOptionPane.INFORMATION_MESSAGE);
    }



    /**
     * Hex addition, subtraction, and Multiplication output
     * @param hexInput1 hex value
     * @param hexInput2 hex value
     * @param decimal1 decimal value
     * @param decimal2 decimal value
     * @param decimalResult decimal sum
     * @param hexResult hex sum
     */
    public ProcessOutput(String operation, HexNum hexInput1, HexNum hexInput2, String decimal1, String decimal2, String decimalResult, String hexResult) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Hex value: \n").append(hexInput1).append(" ").append(operation).append(" ").append(hexInput2).append(" = ").append(hexResult).append("\n");
        stringBuilder.append("Decimal value: \n").append(decimal1).append(" ").append(operation).append(" ").append(decimal2).append(" = ").append(decimalResult);
        JOptionPane.showMessageDialog(null, stringBuilder,"Hexadecimal Calculator", JOptionPane.INFORMATION_MESSAGE);

    }


    /**
     * Hex division output
     * @param input1 hex 1
     * @param input2 hex 2
     * @param decVal1 decimal value 1
     * @param decVal2 decimal value 2
     * @param decimalResult decimal quotient
     * @param remainder dec. remainder
     * @param hexRemainder hex remainder
     * @param hexResult hex quotient
     */
    public static void hexDivisionOutput(HexNum input1, HexNum input2, String decVal1, String decVal2, int decimalResult, int remainder, String hexRemainder, String hexResult) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Hex value: \n").append(input1).append(" ÷ ").append(input2).append(" = ").append(hexResult).append(" Remainder : ").append(hexRemainder).append("\n");
        stringBuilder.append("Decimal value: \n").append(decVal1).append(" ÷ ").append(decVal2).append(" = ").append(decimalResult).append(" Remainder : ").append(remainder).append("\n");
        JOptionPane.showMessageDialog(null, stringBuilder,"Hexadecimal Calculator", JOptionPane.INFORMATION_MESSAGE);


    }


}
