/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package View;

import Model.DecimalNum;

import javax.swing.*;

/**
 * @author Dino Jazvin
 * This class is resposible for
 * properly formatting and displaying output
 */

public class DecimalOutput {

    //Change font color
    public static final String RESET = ("\033[0m");    //Reset color
    public static final String GREEN = "\033[0;32m";   //Green color

    /** Constructor to display adding, subtracting, multiplying, or dividing two DecimalNums
     * @param operation mathematical operation
     * @param input1 DecimalNum 1
     * @param input2 DecimalNum 2
     * @param result Sum/Difference/Product/Quotient of DecimalNums
     */
    public static void DecimalCalcOutput(String operation, DecimalNum input1, DecimalNum input2, double result) {
        if (Double.isInfinite(result)){
            JOptionPane.showMessageDialog(null, "ERROR: Division by 0. \nTry again", "Decimal Calculator", JOptionPane.ERROR_MESSAGE);
        }
        else {
            JOptionPane.showMessageDialog(null, input1 + " " + operation + " " + input2 + "\n" + " = " + result, "Decimal Calculator", JOptionPane.INFORMATION_MESSAGE);
        }
    }




}
