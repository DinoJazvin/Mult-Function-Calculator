/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package View;

import Model.BigIntegerNumber;

import javax.swing.*;
import java.math.BigInteger;

/**
 * @author Dino Jazvin
 * This class displays
 * BigInteger results
 */

public class BigIntegerOutput {

    /**
     * Display BigIntegerNumber output for add, subtract, and multiply
     * @param operation math operation
     * @param input1 BigIntegerNumber value1
     * @param input2 BigIntegerNumber value2
     * @param result the result of the operation
     */
    public static void bigIntOutput(String operation, BigIntegerNumber input1, BigIntegerNumber input2, BigInteger result){
        JOptionPane.showMessageDialog(null, input1 + " " + operation + " " + input2 + "\n = " + result, "BigInteger Calculator", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Display result of division of two BigIntegers
     * @param operation mathematical operation
     * @param input1 BigIntegerNumber 1
     * @param input2 BigIntegerNumber 2
     * @param result Quotient and Remainder of BigIntegerNumbers
     */
    public static void bigIntDivisionOutput(String operation, BigIntegerNumber input1, BigIntegerNumber input2, BigInteger[] result) {
        JOptionPane.showMessageDialog(null, input1 + " " + operation + " " + input2 + "\n = " + result[0] +" Remainder: "+ result[1], "BigInteger Calculator", JOptionPane.INFORMATION_MESSAGE);

    }

}
