/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Model;

/**
 * @author Dino Jazvin
 * This class creates datatype for Hex numbers
 */

public class HexNum extends Number{

    private final String value;

    /**
     * create a HexNum
     * @param s the string holding the value
     */
    public HexNum(String s) {
        this.value = s;
    }

    /**
     * access the value
     * @return value of number
     */
    public String getValue() {
        return value;
    }


    /**
     * get string representation
     * @return string representation of value
     */
    public String toString() {
        return getValue();
    }
}
