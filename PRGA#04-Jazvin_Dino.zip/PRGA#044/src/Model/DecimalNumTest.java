/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests the decimalNum class
 */

class DecimalNumTest {

    DecimalNum decimalNum = new DecimalNum(123);

    @Test
    void getDecimal() {
        assertEquals(123, decimalNum.getDecimal());
    }

    @Test
    void testToString() {
        assertEquals("123.0", decimalNum.toString());
    }
}