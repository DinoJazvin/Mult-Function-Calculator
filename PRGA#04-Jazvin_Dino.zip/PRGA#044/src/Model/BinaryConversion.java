/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Model;

/**
 * @author Dino Jazvin
 * This Interface is resposible for
 * establishing binary conversion methods
 */

public interface    BinaryConversion {
    /**
     * Convert a binary number to equivalent decimal representation
     */
    int convertBinary2Decimal(int binary);

    /**
     * Convert a decimal number to equivalent binary representation
     */
    String convertDecimal2Binary(int n);
}

