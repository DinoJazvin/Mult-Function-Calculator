/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Model;

import View.InputProcessor;

/**
 * @author Dino Jazvin
 * This class is resposible for
 * running the program
 */

public class Main {

    public static void main(String[] args){
        InputProcessor.getCalculatorType();

    }
}