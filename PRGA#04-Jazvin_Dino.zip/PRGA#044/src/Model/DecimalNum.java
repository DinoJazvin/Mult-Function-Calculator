/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Model;

/**
 * @author Dino Jazvin
 * This class creates datatype for Decimal numbers
 */

public class DecimalNum extends Number{

    private final double decimal;

    /**
     * create a DecimalNum
     * @param decimal the double holding the value
     */
    public DecimalNum(double decimal) {
        this.decimal = decimal;
    }

    /**
     * access the value
     * @return value of number
     */
    public double getDecimal() {
        return decimal;
    }

    /**
     * get string representation
     * @return string representation of value
     */
    @Override
    public String toString() {
        return String.valueOf(getDecimal());
    }
}
