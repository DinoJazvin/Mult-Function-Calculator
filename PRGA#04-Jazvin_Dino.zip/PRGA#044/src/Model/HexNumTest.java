/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests the HexNum class
 */

class HexNumTest {

    HexNum hexNum = new HexNum("AA");

    @Test
    void getValue() {
        assertEquals("AA", hexNum.getValue());
    }

    @Test
    void testToString() {
        assertEquals("AA", hexNum.toString());
    }
}