/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */
package Model;

import org.junit.jupiter.api.Test;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * This class tests the BigIntegerNumber class
 */

class BigIntegerNumberTest {

    BigIntegerNumber bigInteger = new BigIntegerNumber(new BigInteger("12"));

    @Test
    void getValue() {
        assertEquals(new BigInteger("12"), bigInteger.getValue());
    }

    @Test
    void testToString() {
        assertEquals("12", bigInteger.toString());
    }
}