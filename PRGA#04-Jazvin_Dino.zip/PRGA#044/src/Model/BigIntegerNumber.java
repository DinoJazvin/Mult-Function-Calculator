/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Model;
import java.math.BigInteger;

/**
 * @author Dino Jazvin
 * This class is the BigIntegerNumber
 */

public class BigIntegerNumber extends Number{

    private final BigInteger value;

    /**
     * Create BigIntegerNumber
     * @param value BigInteger value
     */
    public BigIntegerNumber(BigInteger value){
        this.value = value;
    }

    /**
     * access BigInteger value
     * @return the value
     */
    public BigInteger getValue() {
        return value;
    }

    /**
     * return string representation
     * @return string representation of value
     */
    @Override
    public String toString() {
        return getValue().toString();
    }
}
