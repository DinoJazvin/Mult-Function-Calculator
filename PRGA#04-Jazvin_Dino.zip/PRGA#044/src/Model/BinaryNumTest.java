/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * This class tests the BinaryNum class
 */


class BinaryNumTest {

    BinaryNum num = new BinaryNum("1101");

    @Test
    void getValue() {
        assertEquals("1101", num.getValue());
    }

    @Test
    void testToString() {
        assertEquals("1101", num.toString());
    }
}