/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Model;


/**
 * @author Dino Jazvin
 * This class is intended to be extended by other,
 * more specialized calculator types
 */

public abstract class Number {


    /**
     * No-Arg Constructor
     */
    public Number() {
    }

}
