/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */
package Model;

/**
 * @author Dino Jazvin
 * This class is the BinaryNum datatype
 */

public class BinaryNum extends Number{

    private final String value;

    /**
     * create a BinaryNum
     * @param s String
     */
    public BinaryNum(String s) {
        this.value = s;
    }

    /**
     * access BinaryNum value
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * get String representation
     * @return string representation of value
     */
    public String toString() {
        return getValue();
    }
}
