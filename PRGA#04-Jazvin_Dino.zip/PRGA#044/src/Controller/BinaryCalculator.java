/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Controller;

import Model.BinaryConversion;
import Model.BinaryNum;
import View.ProcessOutput;

/**
 * @author Dino Jazvin
 * This class is resposible for
 * performing binary calculations
 */


public class BinaryCalculator extends NumericCalculator implements BinaryConversion {


    /**
     * Constructor for adding binary values
     * @param input1 Binary value 1
     * @param input2 Binary value 2
     */
    public BinaryCalculator(BinaryNum input1, BinaryNum input2, String operation) {
        String binaryValue;
        ProcessOutput output = new ProcessOutput();
        switch (operation) {
            //add binary
            case "+" -> output.binaryAdditionOutput(addBinary(input1, input2), String.valueOf(convertBinary2Decimal(Integer.parseInt(addBinary(input1, input2)))));
            //subtract binary
            case "-" -> output.binarySubtractionOutput(subtractBinary(input1, input2), String.valueOf(convertBinary2Decimal(Integer.parseInt(subtractBinary(input1, input2)))));
            //multiply binary
            case "x" -> output.binaryMultiplicationOutput(multiplyBinaryRepresentation(input1, input2), String.valueOf(convertBinary2Decimal(Integer.parseInt(multiplyBinaryRepresentation(input1, input2)))));
            //divide binary
            case "÷" -> output.binaryDivisionOutput(divideBinaryQuotient(input1, input2), divideBinaryRemainder(input1, input2), divideDecimalQuotient(input1, input2), divideDecimalRemainder(input1, input2));
        }
    }

    /**
     * No-arg constructor
     */
    public BinaryCalculator() {
    }

    /**
     * Add and return the two binary inputs
     * @param first binary value 1
     * @param second binary value 2
     * @return sum of the two values
     */
    public String addBinary(BinaryNum first, BinaryNum second) {
        String s1 = first.getValue();
        String s2 = second.getValue();
        int b1 = Integer.parseInt(s1, 2);
        int b2 = Integer.parseInt(s2, 2);
        return Integer.toBinaryString(b1 + b2);
    }

    /**
     * subtract and return the two binary inputs
     * @param first binary value 1
     * @param second binary value 2
     * @return difference of the two values
     */
    public String subtractBinary(BinaryNum first, BinaryNum second) {
        String s1 = first.getValue();
        String s2 = second.getValue();
        int b1 = Integer.parseInt(s1, 2);
        int b2 = Integer.parseInt(s2, 2);
        return Integer.toBinaryString(b1 - b2);
    }

    /**
     * Multiplies and returns a binary value for binary 2 values
     * @param num1 value 1
     * @param num2 value 2
     * @return binary product of two binary values
     */
    public String multiplyBinaryRepresentation(BinaryNum num1, BinaryNum num2) {
        String s1 = num1.getValue();
        String s2 = num2.getValue();
        int val1 = convertBinary2Decimal(Integer.parseInt(s1));
        int val2 = convertBinary2Decimal(Integer.parseInt(s2));

        return convertDecimal2Binary(val1 * val2);

    }

    /** Divides and returns a quotient for binary 2 values
     * @param num1 value 1
     * @param num2 value 2
     * @return binary quotient of two binary values
     */
    public String divideBinaryQuotient(BinaryNum num1, BinaryNum num2) {
        String s1 = num1.getValue();
        String s2 = num2.getValue();
        int val1 = convertBinary2Decimal(Integer.parseInt(s1));
        int val2 = convertBinary2Decimal(Integer.parseInt(s2));
        //returning the quotient (Binary)
        return convertDecimal2Binary(val1 / val2);
    }

    /** Divides and returns a remainder
     * @param num1 value 1
     * @param num2 value 2
     * @return binary remainder of two values
     */
    public String divideBinaryRemainder(BinaryNum num1, BinaryNum num2) {
        String s1 = num1.getValue();
        String s2 = num2.getValue();
        int val1 = convertBinary2Decimal(Integer.parseInt(s1));
        int val2 = convertBinary2Decimal(Integer.parseInt(s2));
        //returning the remainder (Binary)
        return  convertDecimal2Binary(val1 % val2);
    }

    /**
     Divides and returns a decimal value for binary 2 values
     * @param num1 value 1
     * @param num2 value 2
     * @return decimal quotient of two binary values
     */
    public int divideDecimalQuotient(BinaryNum num1, BinaryNum num2) {
        String s1 = num1.getValue();
        String s2 = num2.getValue();
        int val1 = convertBinary2Decimal(Integer.parseInt(s1));
        int val2 = convertBinary2Decimal(Integer.parseInt(s2));
        return val1 / val2;
    }

    /**
     Divides and returns a decimal value for binary 2 values
     * @param num1 value 1
     * @param num2 value 2
     * @return decimal quotient of two binary values
     */
    public int divideDecimalRemainder(BinaryNum num1, BinaryNum num2) {
        String s1 = num1.getValue();
        String s2 = num2.getValue();
        int val1 = convertBinary2Decimal(Integer.parseInt(s1));
        int val2 = convertBinary2Decimal(Integer.parseInt(s2));
        return val1 % val2;
    }

    /**
     * Convert a binary number to equivalent decimal representation
     * @param binary input binary number
     * @return decimal form of the input
     */
    @Override
    public int convertBinary2Decimal(int binary) {
        int decimal = 0;
        int n = 0;
        while (true) {
            if (binary == 0) {
                break;
            } else {
                int temp = binary % 10;
                decimal += temp * Math.pow(2, n);
                binary = binary / 10;
                n++;
            }
        }
        return decimal;
    }

    /**
     * Convert a decimal number to equivalent binary representation
     * @param n input decimal number
     * @return binary form of the input
     */
    @Override
    public String convertDecimal2Binary(int n) {

        // array to store binary number
        int[] binaryNum = new int[50];

        // counter for binary array
        int i = 0;
        while (n > 0) {
            // storing remainder in binary array
            binaryNum[i] = n % 2;
            n = n / 2;
            i++;
        }

        StringBuilder strb = new StringBuilder();
        // printing binary array in reverse order
        for (int j = i - 1; j >= 0; j--) {
            strb.append(binaryNum[j]);
        }
        if(strb.toString().equals(""))
            strb.append("0");
        return strb.toString();
    }


}
