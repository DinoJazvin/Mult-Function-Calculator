/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Controller;

import View.ProcessOutput;

/**
 * @author Dino Jazvin
 * This class is resposible for
 * performing bandwidth calculations
 */


public class BandwidthCalculator {


    /**
     * No Arg Constructor. Used to assist the ProcessOutput class
     */
    public BandwidthCalculator() {
    }

    /**
     * Constructor for the data converter
     *
     * @param amount The amount of data
     * @param units  the units of the data
     */
    public BandwidthCalculator(double amount, String units, int operation) {
        if (operation == 1) {
            int position = getUnitsPosition(units);
            double numberOfBits = 0, numberOfBytes = 0;

            if (position < 5) {
                numberOfBits = getBitsOrBytes(position, amount);
            } else {
                numberOfBytes = getBitsOrBytes(position, amount);
            }

            if (numberOfBits > 0) {
                numberOfBytes = numberOfBits * (0.125);
            }

            if (numberOfBytes > 0) {
                numberOfBits = numberOfBytes * (8);
            }

            ProcessOutput output = new ProcessOutput(amount, position, numberOfBits, numberOfBytes);
        }

    }

    /**
     * Constructor for Download/Upload time calc.
     *
     * @param difference the difference in magnitude between the values
     * @param fileSize   the file size
     * @param bandwidth  the bandwidth size
     */
    public BandwidthCalculator(int difference, double fileSize, double bandwidth) {
        int numberOfDays = 0;
        int numberOfHours = 0;
        int numberOfMinutes = 0;
        double factor = 1;

        if (difference > 0) {
            factor = (DivideBy1000(factor, difference));
        } else if (difference < 0) {
            factor = (multiplyBy1000(factor, difference));
        }
        double totalInSeconds = 8 * (factor * (fileSize / bandwidth));

        //number of days
        if (totalInSeconds >= 86400) {
            numberOfDays = getValueOfDaysHoursOrMinutes(totalInSeconds, 86400);
            totalInSeconds = totalInSeconds % 86400;
        }
        //number of Hours
        if (totalInSeconds < 86400 && totalInSeconds >= 3600) {
            numberOfHours = getValueOfDaysHoursOrMinutes(totalInSeconds, 3600);
            totalInSeconds = totalInSeconds % 3600;
        }
        //number of minutes
        if (totalInSeconds < 3600 && totalInSeconds >= 60) {
            numberOfMinutes = getValueOfDaysHoursOrMinutes(totalInSeconds, 60);
            totalInSeconds = totalInSeconds % 60;
        }

        ProcessOutput output = new ProcessOutput(totalInSeconds, numberOfDays, numberOfHours, numberOfMinutes);
    }

    /**
     * Constructor for website Bandwidth calc.
     * @param pageViews total page views
     * @param pageViewsUnits page view units
     * @param averagePageSize average page size
     * @param averagePageSizeUnits units of the average page size
     * @param redundancyFactor redundancy factor
     */
    public BandwidthCalculator(double pageViews, String pageViewsUnits, double averagePageSize, String averagePageSizeUnits, double redundancyFactor) {
        //Bandwidth starting values
        double bandwidthPerSecond = 8.0E-6;
        double bandwidthPerMonth = 0.0026298;

        //Scaling our values by the page views and average page size entered
        bandwidthPerSecond = bandwidthPerSecond * (pageViews) * (averagePageSize);
        bandwidthPerMonth = bandwidthPerMonth * (pageViews) * (averagePageSize);

        int pageViewsDifference = getPageViewDifference(pageViewsUnits);
        int averagePageSizeDifference = getByteUnitsPosition(averagePageSizeUnits);

        //Calculating Bandwidth
        bandwidthPerSecond = convertUsingUnits(pageViewsDifference, averagePageSizeDifference, bandwidthPerSecond);
        bandwidthPerMonth = convertUsingUnits(pageViewsDifference, averagePageSizeDifference, bandwidthPerMonth);

        ProcessOutput output = new ProcessOutput(bandwidthPerSecond, bandwidthPerMonth, redundancyFactor);

    }


    /**
     * Hosting bandwidth calc. option 1
     * @param difference diff in magnitude
     * @param factor the factor
     * @param monthlyUsage value of monthly usage
     * @param monthlyUsageUnits units of monthly usage
     * @param bandwidth value of bandwidth
     * @param bandwidthUnits value of bandwidth units
     */
    public BandwidthCalculator(int difference, double factor, double monthlyUsage, String monthlyUsageUnits, double bandwidth, String bandwidthUnits) {
        if (difference > 0) {
            factor = (DivideBy1000(factor, Math.abs(difference)));
        } else if (difference < 0) {
            factor = (multiplyBy1000(factor, Math.abs(difference)));
        }

        double TotalBandwidth = (factor * (monthlyUsage * bandwidth));
        ProcessOutput output = new ProcessOutput(monthlyUsage, monthlyUsageUnits, TotalBandwidth, bandwidthUnits);
    }

    /**
     * Hosting bandwidth calc. option 2
     * @param difference diff in magnitude
     * @param factor the factor
     * @param monthlyUsage value of monthly usage
     * @param monthlyUsageUnits units of monthly usage
     * @param bandwidth value of bandwidth
     * @param bandwidthUnits value of bandwidth units
     */
    public BandwidthCalculator(int difference, double factor, String monthlyUsageUnits, double monthlyUsage, double bandwidth, String bandwidthUnits) {
        if (difference > 0) {
            factor = (multiplyBy1000(factor, Math.abs(difference)));
        } else if (difference < 0) {
            factor = (DivideBy1000(factor, Math.abs(difference)));
        }

        double TotalMonthlyUsage = (factor * (monthlyUsage * bandwidth));
        ProcessOutput output = new ProcessOutput(bandwidthUnits, bandwidth, TotalMonthlyUsage,monthlyUsageUnits);
    }


    /**
     * Get the index of user chosen units
     *
     * @param choice user chosen units
     * @return index of units
     */
    public int getUnitsPosition(String choice) {
        String[] units = {"b", "kb", "mb", "gb", "tb", "B", "KB", "MB", "GB", "TB"};
        for (int i = 0; i < units.length; i++) {
            if (choice.equals(units[i])) {
                return i;
            }
        }
        return 0;
    }

    /**
     * Get units of the the input
     *
     * @param position index of units
     * @param amount   total
     * @return tne amount of data
     */
    public double getBitsOrBytes(int position, double amount) {
        if (position == 0 || position == 5)
            return amount;
        else if (position == 1 || position == 6) {
            return multiplyBy1000(amount, 1);
        } else if (position == 2 || position == 7) {
            return multiplyBy1000(amount, 2);
        } else if (position == 3 || position == 8) {
            return multiplyBy1000(amount, 3);
        }
        return multiplyBy1000(amount, 4);
    }

    /**
     * Multiply the input by 1000 i times
     *
     * @param amount total
     * @param times  iterations
     * @return the new value
     */
    public static double multiplyBy1000(double amount, int times) {
        double multiplier = 1;
        for (int i = 1; i < times; i++) {
            multiplier *= 1000;
        }
        return amount * (1000 * multiplier);
    }


    /**
     * Divide the input by 1000 i times
     *
     * @param count total
     * @param i     iterations
     * @return the new value
     */
    public double DivideBy1000(double count, int i) {
        while (i > 0) {
            count /= 1000;
            i--;
        }
        return count;
    }

    /**
     * get a division computation, time/divisor
     *
     * @param totalInSeconds total time
     * @param divisor        the divisor
     * @return time / divisor
     */
    public int getValueOfDaysHoursOrMinutes(double totalInSeconds, int divisor) {
        return (int) (totalInSeconds / (divisor));
    }

    /**
     * Computes difference between the unit chosen and seconds
     *
     * @param pageViewsUnits time units chosen by user
     * @return the difference between the unit chosen and seconds
     */
    public static int getPageViewDifference(String pageViewsUnits) {
        String[] units = {"second", "minute", "hour", "day", "week", "month", "year"};
        for (int i = 0; i < units.length; i++) {
            if (units[i].equals(pageViewsUnits))
                return i;
        }
        return 0;
    }

    /**
     * Computes difference regarding Bytes and chosen units
     *
     * @param choice chosen units
     * @return difference between Bytes and chosen units
     */
    public static int getByteUnitsPosition(String choice) {
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        for (int i = 0; i < units.length; i++) {
            if (choice.equals(units[i])) {
                return i;
            }
        }
        return 0;
    }


    /**
     * Get the difference in units from user choice to Bytes
     * @param choice user choice
     * @return difference in units
     */
    public static int getDifferenceInBits(String choice) {
        String[] units = {"b", "kb", "mb", "gb", "tb"};
        for (int i = 0; i < units.length; i++) {
            if (choice.equals(units[i])) {
                return i;
            }
        }
        return 0;
    }

    /**
     * Final Computation of bandwidth
     *
     * @param pageViewsDifference       difference in time units
     * @param averagePageSizeDifference difference in Bytes units
     * @param bandwidth                 the bandwidth
     * @return computed bandwidth
     */
    public static double convertUsingUnits(int pageViewsDifference, int averagePageSizeDifference, double bandwidth) {

        if (pageViewsDifference == 1) {
            bandwidth /= 60;
        } else if (pageViewsDifference == 2) {
            bandwidth /= 3600;
        } else if (pageViewsDifference == 3) {
            bandwidth /= 86400;
        } else if (pageViewsDifference == 4) {
            bandwidth /= 604800;
        } else if (pageViewsDifference == 5) {
            bandwidth /= 2629800;
        } else if (pageViewsDifference == 6) {
            bandwidth /= 31557600;
        }

        if (averagePageSizeDifference != 0) {
            bandwidth = multiplyBy1000(bandwidth, averagePageSizeDifference);
        }

        return bandwidth;
    }

}
