/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Controller;

/**
 * @author Dino Jazvin
 * General class for the numeric calculators
 */

public class NumericCalculator {

    String operand1;
    String operand2;

    /**
     * No-arg Constructor
     */
    public NumericCalculator(){
    }

    /**
     * adds two Number
     * @param a Number 1
     * @param b Number 2
     * @return sum of the Numbers
     */
    public String add(Number a, Number b){
        return a.toString() + b.toString();
    }

    /**
     * subtracts Number 2 from Number 1
     * @param a Number 1
     * @param b Number 2
     * @return difference of the Numbers
     */
    public String subtract(Number a, Number b){
        return a.toString() + b.toString();
    }

    /**
     * multiplies two Numbers
     * @param a Number 1
     * @param b Number 2
     * @return sum of the Numbers
     */
    public String multiply(Number a, Number b){
        return a.toString() + b.toString();
    }

    /**
     * divides two Numbers
     * @param a Number 1
     * @param b Number 2
     * @return quotient of the Numbers
     */
    public String divide(Number a, Number b){
        return a.toString() + b.toString();
    }


}
