/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Controller;

import Model.BigIntegerNumber;
import java.math.BigInteger;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Test the BigIntegerNumber Calculator
 */

class BigIntegerCalculatorTest {

    @org.junit.jupiter.api.Test
    void testAdd() {
        assertEquals(new BigInteger("246264"), BigIntegerCalculator.add(new BigIntegerNumber(new BigInteger("123132")), new BigIntegerNumber(new BigInteger("123132"))));
        assertEquals((new BigInteger("21321")), BigIntegerCalculator.add(new BigIntegerNumber(new BigInteger("0")), new BigIntegerNumber(new BigInteger("21321"))));
        assertEquals((new BigInteger("1089")), BigIntegerCalculator.add(new BigIntegerNumber(new BigInteger("1212")), new BigIntegerNumber(new BigInteger("-123"))));
        assertEquals((new BigInteger("-11")), BigIntegerCalculator.add(new BigIntegerNumber(new BigInteger("0")), new BigIntegerNumber(new BigInteger("-11"))));
    }
    @org.junit.jupiter.api.Test
    void testSubtract() {
        assertEquals(new BigInteger("0"), BigIntegerCalculator.subtract(new BigIntegerNumber(new BigInteger("123132")), new BigIntegerNumber(new BigInteger("123132"))));
        assertEquals(new BigInteger("-21321"), BigIntegerCalculator.subtract(new BigIntegerNumber(new BigInteger("0")), new BigIntegerNumber(new BigInteger("21321"))));
        assertEquals(new BigInteger("1335"), BigIntegerCalculator.subtract(new BigIntegerNumber(new BigInteger("1212")), new BigIntegerNumber(new BigInteger("-123"))));
        assertEquals(new BigInteger("11"), BigIntegerCalculator.subtract(new BigIntegerNumber(new BigInteger("0")), new BigIntegerNumber(new BigInteger("-11"))));
    }@org.junit.jupiter.api.Test
    void testMultiply() {
            assertEquals(new BigInteger("15161489424"), BigIntegerCalculator.multiply(new BigIntegerNumber(new BigInteger("123132")), new BigIntegerNumber(new BigInteger("123132"))));
            assertEquals(new BigInteger("0"), BigIntegerCalculator.multiply(new BigIntegerNumber(new BigInteger("0")), new BigIntegerNumber(new BigInteger("21321"))));
            assertEquals(new BigInteger("-149076"), BigIntegerCalculator.multiply(new BigIntegerNumber(new BigInteger("1212")), new BigIntegerNumber(new BigInteger("-123"))));
            assertEquals(new BigInteger("0"), BigIntegerCalculator.multiply(new BigIntegerNumber(new BigInteger("0")), new BigIntegerNumber(new BigInteger("-11"))));
    }}
