/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */


package Controller;

import Model.HexNum;
import View.ProcessOutput;

/**
 * @author Dino Jazvin
 * This class is resposible for
 * performing hexadecimal calculatations
 */


public class HexadecimalCalculator extends NumericCalculator {

    /**
     * Convert Hexadecimal to Decimal
     * @param num deciding Hex2Dec or Dec2Hex
     * @param input1 Hexadecimal value
     */
    public static void HexadecimalConversion(int num, HexNum input1) {
        //Hex -> Decimal
        if (num == 1) {
           ProcessOutput.Hex2DecimalConverter(Hex2Decimal(input1));
        }
        //Decimal -> Hex
        else {
            boolean status = checkNegative(String.valueOf(input1));
            ProcessOutput.Decimal2HexConverter(Decimal2Hex(String.valueOf(input1), status));
        }
    }


    /**
     * Hex Addition/Subtraction calculation
     *
     * @param operation mathematical operation
     * @param input1    value1
     * @param input2    value2
     */
    public HexadecimalCalculator(String operation, HexNum input1, HexNum input2) {
        switch (operation) {
            case "+" -> {
                int decimalResult = getDecimalResults(input1, input2);
                String decimal1 = Hex2Decimal(input1);
                String decimal2 = Hex2Decimal(input2);
                boolean status = checkNegative(String.valueOf(decimalResult));
                ProcessOutput output = new ProcessOutput(operation, input1, input2, decimal1, decimal2, String.valueOf(decimalResult), addHex(input1, input2));
            }
            case "-" -> {
                String decVal1 = Hex2Decimal(input1);
                String decVal2 = Hex2Decimal(input2);
                String decimalResult = String.valueOf(subtractDecimal(decVal1, decVal2));
                boolean status = checkNegative(decimalResult);
                ProcessOutput output = new ProcessOutput("-", input1, input2, decVal1, decVal2, decimalResult, subtractHex(input1, input2));

            }
            case "x" -> {
                String decVal1 = Hex2Decimal(input1);
                String decVal2 = Hex2Decimal(input2);
                String decimalResult = multiplyDecimal(decVal1, decVal2);
                boolean status = checkNegative(decimalResult);
                ProcessOutput output = new ProcessOutput("*", input1, input2, decVal1, decVal2, decimalResult, multiplyHex(input1, input2));

            }
            case "÷" -> {
                String decVal1 = Hex2Decimal(input1);
                String decVal2 = Hex2Decimal(input2);
                int decimalResult = getQuotient(decVal1, decVal2);
                int remainder = getRemainder(decVal1, decVal2);
                boolean status = checkNegative(String.valueOf(decimalResult));
                String hexRemainder = getRemainderHex(input1, input2);
                ProcessOutput.hexDivisionOutput(input1, input2, decVal1, decVal2, decimalResult, remainder, hexRemainder, divideHex(input1, input2));
            }
        }

    }


    /**
     * No Arg constructor
     */
    public HexadecimalCalculator() {
    }

    /**
     * Return the remainder of the values
     * @param decVal1 value1
     * @param decVal2 value2
     * @return val1 % val2
     */
    public int getRemainder(String decVal1, String decVal2) {
        return Integer.parseInt(decVal1) % Integer.parseInt(decVal2);
    }

    /**
     * Divide two values
     * @param decVal1 value 1
     * @param decVal2 value 2
     * @return quotient of val1/val2
     */
    public int getQuotient(String decVal1, String decVal2) {
        return Integer.parseInt(decVal1) / Integer.parseInt(decVal2);
    }

    /**
     * Multiply two decimals
     * @param decVal1 value 1
     * @param decVal2 value 2
     * @return product of the values
     */
    public String multiplyDecimal(String decVal1, String decVal2) {
        return String.valueOf(Integer.parseInt(decVal1) * Integer.parseInt(decVal2));
    }

    /**
     * Adding two hex values
     * @param input1 value 1
     * @param input2 value 2
     * @return sum of value 1 and value 2
     */
    public String addHex(HexNum input1, HexNum input2){
        String decimal1 = Hex2Decimal(input1);
        String decimal2 = Hex2Decimal(input2);
        int i = Integer.parseInt(decimal1) + Integer.parseInt(decimal2);
        boolean status = checkNegative(String.valueOf(i));
        return Decimal2Hex((String.valueOf(i)), status);
    }

    /**
     * Subtract Hex values
     * @param val1 HexNum one
     * @param val2 HexNum two
     * @return difference of HexNums
     */
    public String subtractHex(HexNum val1, HexNum val2){
        String decimal1 = Hex2Decimal(val1);
        String decimal2 = Hex2Decimal(val2);
        int i = Integer.parseInt(decimal1) - Integer.parseInt(decimal2);
        boolean status = checkNegative(String.valueOf(i));
        return Decimal2Hex((String.valueOf(i)), status);
    }

    /**
     * multiply Hex values
     * @param val1 HexNum one
     * @param val2 HexNum two
     * @return product of HexNums
     */
    public String multiplyHex(HexNum val1, HexNum val2){
        String decimal1 = Hex2Decimal(val1);
        String decimal2 = Hex2Decimal(val2);
        int i = Integer.parseInt(decimal1) * Integer.parseInt(decimal2);
        boolean status = checkNegative(String.valueOf(i));
        return Decimal2Hex((String.valueOf(i)), status);
    }

    /**
     * Divide Hex values
     * @param val1 HexNum one
     * @param val2 HexNum two
     * @return quotient of HexNums
     */
    public String divideHex(HexNum val1, HexNum val2){
        String decimal1 = Hex2Decimal(val1);
        String decimal2 = Hex2Decimal(val2);
        int i = Integer.parseInt(decimal1) / Integer.parseInt(decimal2);
        boolean status = checkNegative(String.valueOf(i));
        return Decimal2Hex((String.valueOf(i)), status);
    }

    /**
     * Divide Hex values
     * @param val1 HexNum one
     * @param val2 HexNum two
     * @return remainder of HexNums
     */
    public String getRemainderHex(HexNum val1, HexNum val2){
        String decimal1 = Hex2Decimal(val1);
        String decimal2 = Hex2Decimal(val2);
        int i = Integer.parseInt(decimal1) % Integer.parseInt(decimal2);
        boolean status = checkNegative(String.valueOf(i));
        return Decimal2Hex((String.valueOf(i)), status);
    }

    /**
     * Subtract decimal values
     * @param val1 input 1
     * @param val2 input 2
     * @return difference of the two values
     */
    public int subtractDecimal(String val1, String val2){
        int num1 = Integer.parseInt(val1);
        int num2 = Integer.parseInt(val2);
        return num1 - num2;
    }

    /**
     * convert hex to decimal value
     * @param input1 hex input
     * @return decimal output
     */
    public static String Hex2Decimal(HexNum input1){
        int decimal = Integer.parseInt(String.valueOf(input1),16);
        return String.valueOf(decimal);
    }

    /**
     * Check if value is negative
     * @param input1 input value
     * @return positive or negative
     */
    public static boolean checkNegative(String input1){
        return input1.charAt(0) == '-';
    }

    /**
     * convert decimal to Hex
     * @param input1 value
     * @param status positive or negative value
     * @return converted hex value
     */
    public static String Decimal2Hex(String input1, boolean status) {
        StringBuilder strb = new StringBuilder(input1);
        if(status){
            strb.deleteCharAt(0);
            String value = Integer.toHexString(Integer.parseInt(String.valueOf(strb)));
            return "-" + value.toUpperCase();
        }
        String value = Integer.toHexString(Integer.parseInt(String.valueOf(strb)));
        return value.toUpperCase();
    }

    /**
     * Return Decimal rep. of adding two HexNum
     * @param input1 HexNum 1
     * @param input2 HexNum 2
     * @return sum
     */
    public int getDecimalResults(HexNum input1, HexNum input2){
        String decimal1 = Hex2Decimal(input1);
        String decimal2 = Hex2Decimal(input2);
        return Integer.parseInt(decimal1) + Integer.parseInt(decimal2);
    }
}

