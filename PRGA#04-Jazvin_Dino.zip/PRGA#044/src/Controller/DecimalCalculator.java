/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Controller;

import Model.DecimalNum;

/**
 * @author Dino Jazvin
 * This class performs
 * decimal calculations
 */

public class DecimalCalculator extends NumericCalculator{

    /**
     * No-arg constructor
     */
    public DecimalCalculator() {
    }


    /**
     * Add two decimal numbers
     * @param num1 DecimalNum one
     * @param num2 DecimalNum two
     * @return sum of two decimal numbers
     */
    public static double addDecimal(DecimalNum num1, DecimalNum num2){
        return num1.getDecimal() + num2.getDecimal();
    }

    /**
     * Subtract DecimalNum two from DecimalNum one
     * @param num1 DecimalNum one
     * @param num2 DecimalNum two
     * @return difference of two DecimalNums
     */
    public static double subtractDecimal(DecimalNum num1, DecimalNum num2){
        return num1.getDecimal() - num2.getDecimal();
    }

    /**
     * Multiply two DecimalNums
     * @param num1 DecimalNum one
     * @param num2 DecimalNum two
     * @return product of two DecimalNums
     */
    public static double multiplyDecimal(DecimalNum num1, DecimalNum num2){
        return num1.getDecimal() * num2.getDecimal();
    }

    /**
     * Divide DecimalNum one by DecimalNum two
     * @param num1 DecimalNum one
     * @param num2 DecimalNum two
     * @return quotient of two DecimalNums
     */
    public static double divideDecimal(DecimalNum num1, DecimalNum num2) {
        return num1.getDecimal() / num2.getDecimal();
    }

}
