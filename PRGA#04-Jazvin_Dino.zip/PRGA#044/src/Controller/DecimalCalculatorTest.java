/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Controller;

import Model.DecimalNum;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Test the Decimal calculator
 */

class DecimalCalculatorTest {

    @Test
    void addDecimal() {
        assertEquals(293, DecimalCalculator.addDecimal(new DecimalNum(170), new DecimalNum(123)));
        assertEquals(999, DecimalCalculator.addDecimal(new DecimalNum(-213), new DecimalNum(1212)));
        assertEquals(0, DecimalCalculator.addDecimal(new DecimalNum(0), new DecimalNum(0)));
        assertEquals(-11, DecimalCalculator.addDecimal(new DecimalNum(0), new DecimalNum(-11)));
    }

    @Test
    void subtractDecimal() {
        assertEquals(47, DecimalCalculator.subtractDecimal(new DecimalNum(170), new DecimalNum(123)));
        assertEquals(-1425, DecimalCalculator.subtractDecimal(new DecimalNum(-213), new DecimalNum(1212)));
        assertEquals(0, DecimalCalculator.subtractDecimal(new DecimalNum(0), new DecimalNum(0)));
        assertEquals(11, DecimalCalculator.subtractDecimal(new DecimalNum(0), new DecimalNum(-11)));
    }

    @Test
    void multiplyDecimal() {
        assertEquals(20910, DecimalCalculator.multiplyDecimal(new DecimalNum(170), new DecimalNum(123)));
        assertEquals(-258156, DecimalCalculator.multiplyDecimal(new DecimalNum(-213), new DecimalNum(1212)));
        assertEquals(0, DecimalCalculator.multiplyDecimal(new DecimalNum(0), new DecimalNum(0)));
        assertEquals(0, DecimalCalculator.multiplyDecimal(new DecimalNum(0), new DecimalNum(11)));
    }

    @Test
    void divideDecimal() {
        assertEquals(1.3821138211382114, DecimalCalculator.divideDecimal(new DecimalNum(170), new DecimalNum(123)));
        assertEquals(-0.17574257425742573, DecimalCalculator.divideDecimal(new DecimalNum(-213), new DecimalNum(1212)));
        assertEquals(828.9088326718771, DecimalCalculator.divideDecimal(new DecimalNum(102132344), new DecimalNum(123213)));
        assertEquals(0, DecimalCalculator.divideDecimal(new DecimalNum(0), new DecimalNum(11)));
    }

}