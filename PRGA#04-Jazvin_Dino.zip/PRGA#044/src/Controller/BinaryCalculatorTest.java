/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Controller;

import Model.BinaryNum;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Test the Binary calculator
 */

class BinaryCalculatorTest {

    BinaryCalculator binaryCalc = new BinaryCalculator();

    @org.junit.jupiter.api.Test
    void addBinary() {
        assertEquals("1010101010", binaryCalc.addBinary(new BinaryNum("1010101010"), new BinaryNum("0")));
        assertEquals("0", binaryCalc.addBinary(new BinaryNum("0"), new BinaryNum("0")));
        assertEquals("1111111111", binaryCalc.addBinary(new BinaryNum("1111111111"), new BinaryNum("0")));
        assertEquals("1111111111111111111111111111111", binaryCalc.addBinary(new BinaryNum("1111111111111111111111111111111"), new BinaryNum("0")));
        assertEquals("11111111111111111111111111111110", binaryCalc.addBinary(new BinaryNum("1111111111111111111111111111111"), new BinaryNum("1111111111111111111111111111111")));
        assertEquals("101110110", binaryCalc.addBinary(new BinaryNum("11001100"), new BinaryNum("10101010")));
        assertEquals("11101001", binaryCalc.addBinary(new BinaryNum("11101"), new BinaryNum("11001100")));
        assertEquals("100000111", binaryCalc.addBinary(new BinaryNum("111011"), new BinaryNum("11001100")));
        assertEquals("10", binaryCalc.addBinary(new BinaryNum("1"), new BinaryNum("1")));
    }

    @org.junit.jupiter.api.Test
    void subtractBinary() {
        assertEquals("0", binaryCalc.subtractBinary(new BinaryNum("0"), new BinaryNum("0")));
        assertEquals("1", binaryCalc.subtractBinary(new BinaryNum("111"), new BinaryNum("110")));
        assertEquals("1010101010", binaryCalc.subtractBinary(new BinaryNum("1010101010"), new BinaryNum("0")));
        assertEquals("1010101010", binaryCalc.subtractBinary(new BinaryNum("1010101010"), new BinaryNum("0")));
        assertEquals("1101000", binaryCalc.subtractBinary(new BinaryNum("11010101"), new BinaryNum("1101101")));
        assertEquals("1111111111111111111111111111111", binaryCalc.subtractBinary(new BinaryNum("1111111111111111111111111111111"), new BinaryNum("0")));
        assertEquals("0", binaryCalc.subtractBinary(new BinaryNum("1111111111111111111111111111111"), new BinaryNum("1111111111111111111111111111111")));
    }

    @org.junit.jupiter.api.Test
    void multiplyBinaryRepresentation() {
        assertEquals("0", binaryCalc.multiplyBinaryRepresentation(new BinaryNum("0"), new BinaryNum("0")));
        assertEquals("101010", binaryCalc.multiplyBinaryRepresentation(new BinaryNum("111"), new BinaryNum("110")));
        assertEquals("0", binaryCalc.multiplyBinaryRepresentation(new BinaryNum("1010101010"), new BinaryNum("0")));
        assertEquals("0", binaryCalc.multiplyBinaryRepresentation(new BinaryNum("11111111"), new BinaryNum("0")));
        assertEquals("101101010110001", binaryCalc.multiplyBinaryRepresentation(new BinaryNum("11010101"), new BinaryNum("1101101")));
        assertEquals("1101111001101000101", binaryCalc.multiplyBinaryRepresentation(new BinaryNum("110111111"), new BinaryNum("1111111011")));
        assertEquals("1000011101111000", binaryCalc.multiplyBinaryRepresentation(new BinaryNum("11001100"), new BinaryNum("10101010")));
        assertEquals("1011100011100", binaryCalc.multiplyBinaryRepresentation(new BinaryNum("11101"), new BinaryNum("11001100")));
        assertEquals("10111100000100", binaryCalc.multiplyBinaryRepresentation(new BinaryNum("111011"), new BinaryNum("11001100")));
        assertEquals("1", binaryCalc.multiplyBinaryRepresentation(new BinaryNum("1"), new BinaryNum("1")));
    }

    @org.junit.jupiter.api.Test
    void divideBinaryQuotient(){
        assertEquals("1", binaryCalc.divideBinaryQuotient(new BinaryNum("1"), new BinaryNum("1")));
        assertEquals("1", binaryCalc.divideBinaryQuotient(new BinaryNum("111"),new BinaryNum("110")));
        assertEquals("1010101010", binaryCalc.divideBinaryQuotient(new BinaryNum("1010101010"),new BinaryNum( "1")));
        assertEquals("10", binaryCalc.divideBinaryQuotient(new BinaryNum("011011"), new BinaryNum("01101")));
        assertEquals("1", binaryCalc.divideBinaryQuotient(new BinaryNum("11010101"),new BinaryNum( "1101101")));
        assertEquals("0", binaryCalc.divideBinaryQuotient(new BinaryNum("1111111"), new BinaryNum("111111111")));
        assertEquals("1", binaryCalc.divideBinaryQuotient(new BinaryNum("11001100"), new BinaryNum("10101010")));
        assertEquals("0", binaryCalc.divideBinaryQuotient(new BinaryNum("11101"), new BinaryNum("11001100")));
        assertEquals("0", binaryCalc.divideBinaryQuotient(new BinaryNum("111011"), new BinaryNum("11001100")));
        assertEquals("1", binaryCalc.divideBinaryQuotient(new BinaryNum("1"), new BinaryNum("1")));
    }

    @org.junit.jupiter.api.Test
    void divideBinaryRemainder(){
        assertEquals("0", binaryCalc.divideBinaryRemainder(new BinaryNum("1"), new BinaryNum("1")));
        assertEquals("1", binaryCalc.divideBinaryRemainder(new BinaryNum("111"),new BinaryNum("110")));
        assertEquals("0", binaryCalc.divideBinaryRemainder(new BinaryNum("1010101010"),new BinaryNum( "1")));
        assertEquals("1", binaryCalc.divideBinaryRemainder(new BinaryNum("011011"), new BinaryNum("01101")));
        assertEquals("1101000", binaryCalc.divideBinaryRemainder(new BinaryNum("11010101"),new BinaryNum( "1101101")));
        assertEquals("1111111", binaryCalc.divideBinaryRemainder(new BinaryNum("1111111"), new BinaryNum("111111111")));
        assertEquals("100010", binaryCalc.divideBinaryRemainder(new BinaryNum("11001100"), new BinaryNum("10101010")));
        assertEquals("11101", binaryCalc.divideBinaryRemainder(new BinaryNum("11101"), new BinaryNum("11001100")));
        assertEquals("111011", binaryCalc.divideBinaryRemainder(new BinaryNum("111011"), new BinaryNum("11001100")));
        assertEquals("0", binaryCalc.divideBinaryRemainder(new BinaryNum("1"), new BinaryNum("1")));
    }

    @org.junit.jupiter.api.Test
    void divideDecimalQuotient(){
        assertEquals(1, binaryCalc.divideDecimalQuotient(new BinaryNum("1"), new BinaryNum("1")));
        assertEquals(1, binaryCalc.divideDecimalQuotient(new BinaryNum("111"),new BinaryNum("110")));
        assertEquals(682, binaryCalc.divideDecimalQuotient(new BinaryNum("1010101010"),new BinaryNum( "1")));
        assertEquals(2, binaryCalc.divideDecimalQuotient(new BinaryNum("011011"), new BinaryNum("01101")));
        assertEquals(1, binaryCalc.divideDecimalQuotient(new BinaryNum("11010101"),new BinaryNum( "1101101")));
        assertEquals(0, binaryCalc.divideDecimalQuotient(new BinaryNum("1111111"), new BinaryNum("111111111")));
        assertEquals(1, binaryCalc.divideDecimalQuotient(new BinaryNum("11001100"), new BinaryNum("10101010")));
        assertEquals(0, binaryCalc.divideDecimalQuotient(new BinaryNum("11101"), new BinaryNum("11001100")));
        assertEquals(0, binaryCalc.divideDecimalQuotient(new BinaryNum("111011"), new BinaryNum("11001100")));
    }

    @org.junit.jupiter.api.Test
    void divideDecimalRemainder(){
        assertEquals(0, binaryCalc.divideDecimalRemainder(new BinaryNum("1"), new BinaryNum("1")));
        assertEquals(1, binaryCalc.divideDecimalRemainder(new BinaryNum("111"),new BinaryNum("110")));
        assertEquals(0, binaryCalc.divideDecimalRemainder(new BinaryNum("1010101010"),new BinaryNum( "1")));
        assertEquals(1, binaryCalc.divideDecimalRemainder(new BinaryNum("011011"), new BinaryNum("01101")));
        assertEquals(104, binaryCalc.divideDecimalRemainder(new BinaryNum("11010101"),new BinaryNum( "1101101")));
        assertEquals(127, binaryCalc.divideDecimalRemainder(new BinaryNum("1111111"), new BinaryNum("111111111")));
        assertEquals(34, binaryCalc.divideDecimalRemainder(new BinaryNum("11001100"), new BinaryNum("10101010")));
        assertEquals(29, binaryCalc.divideDecimalRemainder(new BinaryNum("11101"), new BinaryNum("11001100")));
        assertEquals(59, binaryCalc.divideDecimalRemainder(new BinaryNum("111011"), new BinaryNum("11001100")));

    }

    @org.junit.jupiter.api.Test
    void convertBinary2Decimal() {
        assertEquals(170, binaryCalc.convertBinary2Decimal(10101010));
        assertEquals(1023, binaryCalc.convertBinary2Decimal(1111111111) );
        assertEquals(0, binaryCalc.convertBinary2Decimal(0));
        assertEquals(698 ,binaryCalc.convertBinary2Decimal(1010111010));
        assertEquals(512 ,binaryCalc.convertBinary2Decimal(1000000000));
    }

    @org.junit.jupiter.api.Test
    void convertDecimal2Binary() {
        assertEquals("10101010", binaryCalc.convertDecimal2Binary(170));
        assertEquals("1111111111", binaryCalc.convertDecimal2Binary(1023));
        assertEquals("0", binaryCalc.convertDecimal2Binary(0));
        assertEquals("1000010001110100011010111000111", binaryCalc.convertDecimal2Binary(1111111111));
        assertEquals("111011100110101100100111111111", binaryCalc.convertDecimal2Binary(999999999));
    }



}