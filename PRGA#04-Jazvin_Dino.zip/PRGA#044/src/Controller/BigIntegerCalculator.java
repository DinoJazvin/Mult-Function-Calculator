/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Controller;

import Model.BigIntegerNumber;
import java.math.BigInteger;

/**
 * Perform BigIntegerNumber calculations
 */

public class BigIntegerCalculator {


    /**
     * No Arg Constructor
     */
    public BigIntegerCalculator() {

    }

    /**
     * Add two BigIntegerNumber numbers
     * @param num1 BigIntegerNumber one
     * @param num2 BigIntegerNumber two
     * @return sum of two BigIntegerNumber numbers
     */
    public static BigInteger add(BigIntegerNumber num1, BigIntegerNumber num2){
        return num1.getValue().add(num2.getValue());
    }

    /**
     * Subtract BigIntegerNumber two from BigInteger one
     * @param num1 BigIntegerNumber one
     * @param num2 BigIntegerNumber two
     * @return difference of two BigIntegerNumber numbers
     */
    public static BigInteger subtract(BigIntegerNumber num1, BigIntegerNumber num2) {
        return num1.getValue().subtract(num2.getValue());
    }

    /**
     * Multiply two BigIntegerNumber values
     * @param num1 BigIntegerNumber one
     * @param num2 BigIntegerNumber two
     * @return product of two BigIntegerNumber numbers
     */
    public static BigInteger multiply(BigIntegerNumber num1, BigIntegerNumber num2) {
        return num1.getValue().multiply(num2.getValue());
    }

    /**
     * Divide two BigIntegerNumber values
     * @param num1 BigIntegerNumber one
     * @param num2 BigIntegerNumber two
     * @return quotient and remainder of two BigIntegerNumber numbers
     */
    public static BigInteger[] divide(BigIntegerNumber num1, BigIntegerNumber num2) {
        return num1.getValue().divideAndRemainder(num2.getValue());
    }

}
