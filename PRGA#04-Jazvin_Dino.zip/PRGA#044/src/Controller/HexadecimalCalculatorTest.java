/*
 * TCSS 305
 * Version 4.0
 * 6.12.2021
 */

package Controller;

import Model.HexNum;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Test Hexadecimal calculator
 */

class HexadecimalCalculatorTest {

    HexadecimalCalculator hex = new HexadecimalCalculator();

    @Test
     void addHex() {
        assertEquals("1B9", hex.addHex(new HexNum("FF"), new HexNum("BA")));
        assertEquals("313B0B", hex.addHex(new HexNum("312FED"), new HexNum("B1E")));
        assertEquals("10E", hex.addHex(new HexNum("FF"), new HexNum("F")));
        assertEquals("0", hex.addHex(new HexNum("0"), new HexNum("0")));
        assertEquals("A1F6", hex.addHex(new HexNum("A2E4"), new HexNum("-EE")));
    }

    @Test
    void getDecimalResults() {
        assertEquals(441, hex.getDecimalResults(new HexNum("FF"), new HexNum("BA")));
        assertEquals(3226379, hex.getDecimalResults(new HexNum("312FED"), new HexNum("B1E")));
        assertEquals(270, hex.getDecimalResults(new HexNum("FF"), new HexNum("F")));
        assertEquals(0, hex.getDecimalResults(new HexNum("0"), new HexNum("0")));
        assertEquals(41462, hex.getDecimalResults(new HexNum("A2E4"), new HexNum("-EE")));
        assertEquals(-41938, hex.getDecimalResults(new HexNum("-A2E4"), new HexNum("-EE")));
    }

    @Test
    void Hex2Decimal() {
        assertEquals("255", HexadecimalCalculator.Hex2Decimal(new HexNum("FF")));
        assertEquals("3501", HexadecimalCalculator.Hex2Decimal(new HexNum("DAD")));
        assertEquals("3056829", HexadecimalCalculator.Hex2Decimal(new HexNum("2EA4bD")));
        assertEquals("-174", HexadecimalCalculator.Hex2Decimal(new HexNum("-AE")));
        assertEquals("0", HexadecimalCalculator.Hex2Decimal(new HexNum("0")));
    }

    @Test
    void Decimal2Hex() {
        assertEquals("AA", HexadecimalCalculator.Decimal2Hex("170", false));
        assertEquals("7D0", HexadecimalCalculator.Decimal2Hex("2000", false));
        assertEquals("DC9AEE0", HexadecimalCalculator.Decimal2Hex("231321312", false));
        assertEquals("140C0", HexadecimalCalculator.Decimal2Hex("82112", false));
        assertEquals("0", HexadecimalCalculator.Decimal2Hex("0", false));
    }

    @Test
    void subtractHex() {
        assertEquals("2F", hex.subtractHex(new HexNum("AA"), new HexNum("7B")));
        assertEquals("3E7", hex.subtractHex(new HexNum("-D5"), new HexNum("-4BC")));
        assertEquals("0", hex.subtractHex(new HexNum("0"), new HexNum("0")));
        assertEquals("B", hex.subtractHex(new HexNum("0"), new HexNum("-B")));
    }

    @Test
    void subtractDecimal() {
        assertEquals(47, hex.subtractDecimal("170", "123"));
        assertEquals(-1425, hex.subtractDecimal("-213", "1212"));
        assertEquals(0, hex.subtractDecimal("0", "0"));
        assertEquals(11, hex.subtractDecimal("0", "-11"));
    }

    @Test
    void multiplyHex() {
        assertEquals("B946", hex.multiplyHex(new HexNum("FF"), new HexNum("BA")));
        assertEquals("22D2CCC6", hex.multiplyHex(new HexNum("312FED"), new HexNum("B1E")));
        assertEquals("EF1", hex.multiplyHex(new HexNum("FF"), new HexNum("F")));
        assertEquals("0", hex.multiplyHex(new HexNum("0"), new HexNum("0")));
        assertEquals("-976FF8", hex.multiplyHex(new HexNum("A2E4"), new HexNum("-EE")));
    }

    @Test
    void multiplyDecimal() {
        assertEquals("47430", hex.multiplyDecimal("255", "186"));
        assertEquals("584240326", hex.multiplyDecimal("3223533", "2846"));
        assertEquals("3825", hex.multiplyDecimal("255", "15"));
        assertEquals("-9924600", hex.multiplyDecimal("41700", "-238"));
    }

    @Test
    void divideHex() {
        assertEquals("1", hex.divideHex(new HexNum("FF"), new HexNum("BA")));
        assertEquals("46C", hex.divideHex(new HexNum("312FED"), new HexNum("B1E")));
        assertEquals("11", hex.divideHex(new HexNum("FF"), new HexNum("F")));
        assertEquals("-AF", hex.divideHex(new HexNum("A2E4"), new HexNum("-EE")));
    }

    @Test
    void getRemainderHex() {
        assertEquals("45", hex.getRemainderHex(new HexNum("FF"), new HexNum("BA")));
        assertEquals("745", hex.getRemainderHex(new HexNum("312FED"), new HexNum("B1E")));
        assertEquals("0", hex.getRemainderHex(new HexNum("FF"), new HexNum("F")));
        assertEquals("32", hex.getRemainderHex(new HexNum("A2E4"), new HexNum("-EE")));
    }

    @Test
    void getQuotient() {
        assertEquals(1, hex.getQuotient("255", "186"));
        assertEquals(1132, hex.getQuotient("3223533", "2846"));
        assertEquals(17, hex.getQuotient("255", "15"));
        assertEquals(-175, hex.getQuotient("41700", "-238"));
    }

    @Test
    void getRemainder() {
        assertEquals(69, hex.getRemainder("255", "186"));
        assertEquals(1861, hex.getRemainder("3223533", "2846"));
        assertEquals(0, hex.getRemainder("255", "15"));
        assertEquals(50, hex.getRemainder("41700", "-238"));
    }
}